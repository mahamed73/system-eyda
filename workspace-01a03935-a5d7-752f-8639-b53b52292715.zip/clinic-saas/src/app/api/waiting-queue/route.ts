import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { query } from "@/lib/db";

/**
 * GET /api/waiting-queue
 * المرضى اللي "حضروا" النهاردة ولسه مكشفوش (status = 'arrived') بترتيب الوصول.
 * بيستخدم في كارت قائمة الانتظار وفي الـ live poller.
 */
export async function GET() {
  const sessionOrError = await requireSession();
  if (sessionOrError instanceof NextResponse) return sessionOrError;
  const { clinicId } = sessionOrError;

  const today = new Date().toISOString().slice(0, 10);

  const { rows } = await query<{
    id: string;
    patient_id: string;
    patient_name: string;
    patient_phone: string;
    arrived_at: string;
    visit_type: string;
  }>(
    `SELECT a.id, a.patient_id, p.full_name AS patient_name, p.phone AS patient_phone,
            a.scheduled_at::text AS arrived_at, a.visit_type
     FROM appointments a
     JOIN patients p ON p.id = a.patient_id
     WHERE a.clinic_id = $1
       AND a.scheduled_at::date = $2
       AND a.status = 'arrived'
     ORDER BY a.scheduled_at ASC`,
    [clinicId, today]
  );

  return NextResponse.json({ data: rows, count: rows.length });
}
